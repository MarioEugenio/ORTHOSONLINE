<?php

namespace Orthos\Bundle\PacienteBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OrthosPacienteBundle extends Bundle
{
}
