<?php

namespace Orthos\Bundle\ProntuarioBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OrthosProntuarioBundle extends Bundle
{
}
