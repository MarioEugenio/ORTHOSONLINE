<?php
namespace Orthos\Bundle\ProntuarioBundle\Model;

use Orthos\Bundle\ClinicaBundle\Entity\Paciente;

class ProcedimentoArealizarModel extends \abstraction\model\AbstractModel
{
    protected $repository = 'OrthosProntuarioBundle:ProcedimentosARealizar';
}
