<?php

namespace Orthos\Bundle\FinanceiroBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OrthosFinanceiroBundle extends Bundle
{
}
