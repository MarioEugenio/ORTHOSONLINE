<?php

namespace Orthos\Bundle\RelatoriosBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OrthosRelatoriosBundle extends Bundle
{
}
