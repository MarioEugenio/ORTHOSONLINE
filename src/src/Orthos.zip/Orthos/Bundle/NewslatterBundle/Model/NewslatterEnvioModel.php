<?php
namespace Orthos\Bundle\NewslatterBundle\Model;

use Orthos\Bundle\ClinicaBundle\Entity\Paciente;

class NewslatterEnvioModel extends \abstraction\model\AbstractModel
{
    protected $repository = 'OrthosNewslatterBundle:NewslatterEnvio';
}
