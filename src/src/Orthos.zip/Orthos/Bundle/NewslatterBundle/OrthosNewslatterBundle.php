<?php

namespace Orthos\Bundle\NewslatterBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OrthosNewslatterBundle extends Bundle
{
}
