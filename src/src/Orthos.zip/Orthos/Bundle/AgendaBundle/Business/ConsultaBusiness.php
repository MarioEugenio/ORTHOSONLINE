<?php
namespace Orthos\Bundle\AgendaBundle\Business;

use Orthos\Bundle\ClinicaBundle\Entity\Paciente;

class ConsultaBusiness extends \abstraction\business\AbstractBusiness
{
    protected $model = '\Orthos\Bundle\AgendaBundle\Model\ConsultaModel';


}
