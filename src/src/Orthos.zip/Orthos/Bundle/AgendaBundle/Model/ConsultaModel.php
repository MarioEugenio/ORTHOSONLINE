<?php
namespace Orthos\Bundle\AgendaBundle\Model;

use Orthos\Bundle\ClinicaBundle\Entity\Paciente;

class ConsultaModel extends \abstraction\model\AbstractModel
{
    protected $repository = 'OrthosAgendaBundle:Consulta';
}
