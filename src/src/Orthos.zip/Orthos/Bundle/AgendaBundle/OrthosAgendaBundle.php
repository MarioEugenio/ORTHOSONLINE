<?php

namespace Orthos\Bundle\AgendaBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OrthosAgendaBundle extends Bundle
{
}
