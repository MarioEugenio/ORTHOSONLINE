<?php

namespace Orthos\Bundle\MediaBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OrthosMediaBundle extends Bundle
{
}
