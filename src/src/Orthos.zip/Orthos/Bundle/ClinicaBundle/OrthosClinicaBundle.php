<?php

namespace Orthos\Bundle\ClinicaBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OrthosClinicaBundle extends Bundle
{
}
