<?php
namespace Orthos\Bundle\ClinicaBundle\Business;

use Orthos\Bundle\ClinicaBundle\Entity\Paciente;

class ConvenioBusiness extends \abstraction\business\AbstractBusiness
{
    protected $model = '\Orthos\Bundle\ClinicaBundle\Model\ConvenioModel';

}
