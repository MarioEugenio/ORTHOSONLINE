<?php

namespace Orthos\Bundle\ClinicaBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * PacienteStatus
 *
 * @ORM\Table(name="tb_paciente_status")
 * @ORM\Entity
 */
class PacienteStatus extends \abstraction\entity\AbstractEntity
{
    /**
     * @var integer
     *
     * @ORM\Column(name="sq_paciente_status", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $sq_paciente_status;

    /**
     * @var string
     *
     * @ORM\Column(name="no_status", type="string", length=100)
     */
    private $no_status;


    /**
     * Get sq_paciente_status
     *
     * @return integer 
     */
    public function getSqStatus()
    {
        return $this->sq_paciente_status;
    }

    /**
     * Set no_status
     *
     * @param string $noStatus
     * @return PacienteStatus
     */
    public function setNoStatus($noStatus)
    {
        $this->no_status = $noStatus;
    
        return $this;
    }

    /**
     * Get no_status
     *
     * @return string 
     */
    public function getNoStatus()
    {
        return $this->no_status;
    }
}
