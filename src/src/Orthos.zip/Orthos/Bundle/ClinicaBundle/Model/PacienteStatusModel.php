<?php
namespace Orthos\Bundle\ClinicaBundle\Model;

use Orthos\Bundle\ClinicaBundle\Entity\Paciente;
use Orthos\Bundle\ClinicaBundle\Entity\Clinica;

class PacienteStatusModel extends \abstraction\model\AbstractModel
{
    protected $repository = 'OrthosClinicaBundle:PacienteStatus';
}
