<?php
namespace Orthos\Bundle\MensagemBundle\Model;

use Orthos\Bundle\ClinicaBundle\Entity\Paciente;

class MensagemModel extends \abstraction\model\AbstractModel
{
    protected $repository = 'OrthosMensagemBundle:Mensagem';
}
