<?php

namespace Orthos\Bundle\MensagemBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OrthosMensagemBundle extends Bundle
{
}
